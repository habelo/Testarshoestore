CREATE PROCEDURE addToCart(IN costumerID INT, IN purchase_orderID INT, IN shoe_ID INT)
  begin
declare lastid int default 0;
declare exit handler for sqlexception
    begin
		rollback;
		select 'sqlexception' as e;
	end;
declare exit handler for sqlwarning
	begin
		rollback;
		select 'varning' as e;
	end;
declare exit handler for 1062
	begin
		rollback;
		select 'same name' as e;
	end;
set autocommit =0;
start transaction;
if (select stockAmount from shoe where id = shoe_ID) =0 then
	select 'ingen i lager';
elseif purchase_orderID = 0 or purchase_orderID = null then
    insert into purchase(costumerid) value(costumerID);
    select last_insert_id() into lastid;
    insert into purchase_order(purchaseid) value (lastid);
    select last_insert_id() into lastid;
    insert into sale(shoeid, orderid) values (shoe_ID, lastid);
    update shoe set stockAmount =(stockAmount-1) where id = shoe_ID;
else
    insert into sale(shoeid, orderid) values (shoe_ID, purchase_orderID);
    update shoe set stockAmount =(stockAmount-1) where id = shoe_ID;
	end if;
commit;
set autocommit =1;
end;

