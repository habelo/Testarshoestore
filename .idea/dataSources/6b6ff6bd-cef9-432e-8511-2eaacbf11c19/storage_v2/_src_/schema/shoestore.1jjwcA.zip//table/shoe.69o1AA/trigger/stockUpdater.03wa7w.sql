CREATE TRIGGER stockUpdater
  AFTER UPDATE
  ON shoe
  FOR EACH ROW
  begin
    if new.stockAmount = 0 then
    insert into outOfStock (shoeid) value (old.id);
    end if;
    end;

